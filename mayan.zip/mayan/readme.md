# To use the current configuration:

1. Copy the whole folder "/mayan" to "home" for example.

2. The current configuration uses localhost as the common name, in case you wanted to use another ip address replace the content of "/certs" **the certificate and the private key** by generating new ones.

3. Generate a new certificate and a new private key using the following command:

    > Replace the common name with the new ip address.

    ```console
    cd certs
    openssl req -x509 -nodes -days 3650 -newkey rsa:2048 \
    -keyout ./certs/mayan.key \
    -out ./certs/mayan.crt \
    -subj "/C=US/ST=State/L=City/O=Internal/CN=localhost"
    ```

4. In case you decided to set-up a new address other than "localhost" you need to replace the occureneces of the latter with the new ip address in: nginx.conf and docker-compose.yaml

5. Execute the following command:

    > Internet connection is needed to pull the necessary images

    ```console
    sudo docker compose up -d
    ```

6. Everything is now set-up, mayan-edms can be accessed via the url: https://localhost.